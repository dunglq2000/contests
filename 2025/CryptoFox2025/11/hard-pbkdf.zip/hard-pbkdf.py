from Crypto.Cipher import AES
from hashlib import pbkdf2_hmac, sha256
from cryptography.hazmat.primitives import padding

def GetKeyByPassword(password: bytes):
    hash = sha256()
    hash.update(password)
    key = hash.digest()
    return key

def GetIvByPassword(password: bytes):
    salt = b'\x00' * 16
    reps = 2**30
    iv = pbkdf2_hmac('sha256', password, salt, reps)[:16]
    return iv

def Encrypt(key: bytes, iv: bytes):
    for i in range(4):
        cipher = AES.new(key, AES.MODE_CBC, iv=iv)
        filename = f'{i}.in'
        plaintext = b''

        with open(filename, 'rb') as file:
            plaintext = file.read()
        
        padder = padding.PKCS7(128).padder()
        plaintext_pad = padder.update(plaintext) + padder.finalize()
        ciphertext = cipher.encrypt(plaintext_pad)
        filename = f'{i}.out'

        with open(filename, 'wb') as file:
            file.write(ciphertext)

def main():
    with open('password.txt', 'rb') as file:
        password =  file.read()

    key = GetKeyByPassword(password)
    iv  = GetIvByPassword(password)
    Encrypt(key, iv)

if __name__ == '__main__':
    main()
